<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pre_inscricao extends Controller
{
    //
}
