@extends("layouts.index")
@section("title","pre escolar")

@section("content")
@include("layouts.header")
<div class="pb-40"></div>
<div class=" main w-11/12 fundador_layout pt-10 md:flex-row flex-col sm:flex-col md:w-screan md:p-0 ">
    <div class="perfil pt-10 md:w-4/12 w-full flex items-start">
        <h1 class="text-orange text-5xl font-bold border-b text-rigth pb-5 border-orange pt-10">
           
2ºGrau (EP2)</h1>
       
        
       
      </div>
  
  
    <div class="left w-full md:w-8/12">
     
        <p>
           
O ensino primário do 2º grau compreende à 6ª e 7ª classe correspondentes ao 3º ciclo.</p>
            <h1>conpetencias</h1>
     <ol>
        <li>
            <p>A criança vai consolidar e ampliar os conhecimentos, habilidades adquiridos nos ciclos anteriores, e ser preparada para dar continuidade dos estudos no ensino secundário e para a vida.</p>
        </li>
        
     </ol>
<p class="text-red-400 pt-5 text-2xl ">PREVISÃO POR ANUNCIAR</p>
    </div>
    


</div>
@endsection


