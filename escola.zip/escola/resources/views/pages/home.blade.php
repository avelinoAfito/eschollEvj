<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../../css/header.css">
  @vite('resources/css/app.css') 
</head>
<body>
 <div>
    <nav class="logo">

    </nav>
    <nav>
        <a href="">Inicio</a>
        <a href="">Instituicional</a>
        <a href="">Academico</a>
        <a href="">Equipe</a>
        <a href="">Galeria</a>
        <a href="">Servicos</a>
        <a href="">Matriculas</a>
        <a href="">Doar</a>
        <a href="">Duvidas</a>
        <a href="">Duvidas</a>
        <a href="">Contacto</a>
    </nav>
 </div>

</body>
</html>