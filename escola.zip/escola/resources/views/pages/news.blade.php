@extends('layouts.index');

@section("title","Ecola evanjafrica News");

@section("content")

<div class="main">

   

  
    <div class="destaques">
        <div class="card ">
            <img src="/files/image/01-1024x678-400x269.jpg" alt="" srcset="">
            <h1>titulo</h1>
        </div>
        


    </div>

</div>


@endsection