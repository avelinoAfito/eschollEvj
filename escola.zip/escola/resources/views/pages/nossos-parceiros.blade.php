@extends("layouts.index")

@section("title","nossos parceiros")

@section('content')

@include("layouts.header")

<div class="main">
    <div>
        <img src="/files/image/freeparca.png" alt="" srcset="">
    </div>
</div>
    
@endsection
