

<?php $__env->startSection("title","nossos parceiros"); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main">
    <div>
        <img src="/files/image/freeparca.png" alt="" srcset="">
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personale\dEV\projectos\php\fremework\Laravel\Evanjafrica Escola\escola\resources\views/pages/nossos_parceiros.blade.php ENDPATH**/ ?>