<div class="text-white flex text-lg justify-center item fixed header bg-black " >
    <div class="navBar">
      <div class="flex items-center content-center">
        <img src="/files/image/logosite.png" id="logo" alt="" srcset="">
      </div> 
        <nav class=" flex gap-5 text-black border-orange navbarItem">
          <ul class="flex items-center gap-5">     
            <li> <a href="/">INÍCIO</a></li>
            <li><a href="">INSTITUCIONAl</a>
            
            <div class="drop absolute lowrcase bg-white p-5 mt-16 rounded-md none">
              <ul>
                <li>
                  <a href="">Quem Somos</a>
                </li>
                <li>
                  <a href="">Palavras do Fundador</a>
                </li>
                <li>
                  <a href="">Nossos Parceiros</a>
                </li>
                <li>
                  <a href="">Regulamentos</a>
                </li>
                <li>
                  <a href="">Eventos Agendas</a>
                </li>
              </ul>
            </div>
            </li>
            <li> <a href="">ACADÉMICO</a>
  
              <div class="drop absolute lowrcase bg-white p-5 mt-16 rounded-md">
                <ul>
                  <li>
                    <a href="">pre-escolar</a>
                  </li>
                  <li>
                    <a href="">1 Grau (EP1)</a>
                  </li>
                  <li>
                    <a href="">1 Grau (EP2)</a>
                  </li>
                  <li>
                    <a href="">Ensino Secundario</a>
                  </li>
                  <li>
                    <a href="">actividade extra</a>
                  </li>
                  <li>
                    <a href="">Tecnico Professional</a>
                  </li>
                </ul>
              </div>
            
            </li>
            <li> <a href="">EQUIPE</a></li>
            <li><a href="">GALeRIA</a></li>
            <li> <a href="">SERVIÇOS</a>
              <div class="drop absolute lowrcase bg-white p-5 mt-16 rounded-md">
                <ul >
                  <li class=" text-white bg-red-200">
                    <a href=""  >Biblioteca</a>
                  </li>
                  <li>
                    <a href="">Loja</a>
                  </li>
                  <li>
                    <a href="">Cantina Escola</a>
                  </li>
                  <li>
                    <a href="">Sala de informatica</a>
                  </li>
                  <li>
                    <a href="">Transporte Escolar</a>
                  </li>
                  <li>
                    <a href="">Tecnico Professional</a>
                  </li>
                </ul>
              </div>
            
            </li>
            <li> <a href="">MATRÍCULAS</a></li>
            <li><a href="">DOAR</a></li>
            <li><a href="">DÚVIDAS</a></li>
            <li><a href="">CONTATO</a></li>
          </ul>        
        </nav>
    </div>
   
   </div>
   <div class="pb-40"></div><?php /**PATH D:\Personale\dEV\projectos\php\fremework\Laravel\Evanjafrica Escola\escola\resources\views/layouts/sbheader.blade.php ENDPATH**/ ?>