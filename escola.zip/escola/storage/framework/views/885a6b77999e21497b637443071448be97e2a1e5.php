<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?> 
</head>
<body>
 <div class="bg-white text-white flex text-lg justify-center item fixed header" >
  <div class="navBar">
    <div class="flex items-center content-center">
      <img src="/files/image/logosite-light-150x121.png" alt="" srcset="">
    </div> 
      <nav class=" flex gap-5 text-black border-orange">
        <ul class="flex items-center gap-5">     
          <li> <a href="">INÍCIO</a></li>
          <li><a href="">INSTITUCIONAl</a></li>
          <li> <a href="">ACADÉMICO</a></li>
          <li> <a href="">EQUIPE</a></li>
          <li><a href="">GALeRIA</a></li>
          <li> <a href="">SERVIÇOS</a></li>
          <li> <a href="">MATRÍCULAS</a></li>
          <li><a href="">DOAR</a></li>
          <li><a href="">DÚVIDAS</a></li>
          <li><a href="">CONTATO</a></li>
        </ul>        
      </nav>
  </div>
 
 </div>
    <?php echo $__env->yieldContent('content'); ?>

    <section class="footer w-full">
        <div>
           <p>Somos o Ministério Evanjáfrica, uma organização de carácter social, sem fins lucrativos e de índole Cristã. Convertemos o nosso</p>
        <p>Departamento de Educação e Formação em uma Instituição de Ensino Formal denominada ESCOLA EVANJÁFRICA.</p>
          </div>
        <div>
          <p>E-mail: info.escolaevanjafrica@gmail.com |  Telefone: 843324689</p>
        </div>
        <div>
          <p>
            © 2022 Escola Evanjáfrica. Todos os direitos reservados.
          </p>
        </div>
      
      
      </section>
      
    
</body>
</html><?php /**PATH D:\Personale\dEV\projectos\php\fremework\Laravel\Evanjafrica Escola\escola\resources\views//layouts/index.blade.php ENDPATH**/ ?>