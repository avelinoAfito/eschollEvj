;

<?php $__env->startSection("title","Ecola evanjafrica News"); ?>;

<?php $__env->startSection("content"); ?>

<div class="main">

   

  
    <div class="destaques">
        <div class="card ">
            <img src="/files/image/01-1024x678-400x269.jpg" alt="" srcset="">
            <h1>titulo</h1>
        </div>
        


    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personale\dEV\projectos\php\fremework\Laravel\Evanjafrica Escola\escola\resources\views/pages/news.blade.php ENDPATH**/ ?>